# The generated surface nixfied derives for an adopting project from its
# module (VERB-1, the corrected split of SURFACE-1):
#
# - the **framework project apps**, framework-owned discovery and controls;
# - the **project verbs**, adopter-owned: one app per task id exported in
#   `nixfied.surface.verbs` (`.#check` -> `runtime run --task check`).
#
# Runtime-backed apps use the model store path baked in at evaluation. The help
# app instead projects final flake metadata through Nix and never enters the
# runtime, so SEAM-1 remains intact.
{
  module,
  pkgs,
  lib,
  runtime,
  system,
  model,
  config,
}:
let
  modulePath = toString module;
  moduleRoot = builtins.dirOf modulePath;
  moduleIsProjectRoot =
    builtins.isPath module
    && builtins.baseNameOf modulePath == "nixfied.nix"
    && builtins.pathExists "${moduleRoot}/flake.nix"
    && builtins.pathExists "${moduleRoot}/flake.lock";
  runtimeBin = "${runtime}/bin/nixfied-runtime";
  modelJson = "${model}/model.json";
  verbs = config.nixfied.surface.verbs;
  mkApp =
    name: description: text:
    let
      drv = pkgs.writeShellApplication { inherit name text; };
    in
    {
      type = "app";
      program = "${drv}/bin/${name}";
      meta.description = description;
    };
  # `validate.nix` already proved each verb names a declared task and avoids
  # the framework namespace; this projection just derives the apps.
  verbApps = builtins.listToAttrs (
    map (verb: {
      name = verb;
      value =
        mkApp verb "Run the Nixfied task '${verb}'"
          ''exec "${runtimeBin}" run --model "${modelJson}" --task "${verb}" "$@"'';
    }) verbs
  );
in
assert lib.assertMsg moduleIsProjectRoot "lib.projectApps requires project-root flake.nix, flake.lock, and nixfied.nix";
{
  help = import ./help-app.nix {
    inherit pkgs system;
    expectedFlakePath = moduleRoot;
    flakeRef = ".";
  };

  # Run one selected task (`nix run .#run -- --task <id>`): its derived
  # service union starts eagerly, then the flattened nodes execute. With no
  # selection the runtime refuses and lists the declared tasks.
  run =
    mkApp "run" "Run one declared Nixfied task"
      ''exec "${runtimeBin}" run --model "${modelJson}" "$@"'';

  # Admission sanity: the model is well-formed and admits (cheap, no
  # execution). Named `model-check` so `check` stays free for adopters.
  model-check =
    mkApp "model-check" "Admit the compiled Nixfied model without executing tasks"
      ''exec "${runtimeBin}" check --model "${modelJson}" "$@"'';

  # Recovery/control surface over the project's slots: observe registry-owned
  # processes (reconciling stale evidence), stop everything the runtime owns,
  # and remove the marker-gated slot state. Extra args are forwarded
  # (e.g. `nix run .#down -- --slot 1`).
  ps =
    mkApp "ps" "Reconcile and report Nixfied-owned processes for a slot"
      ''exec "${runtimeBin}" ps --model "${modelJson}" "$@"'';
  down =
    mkApp "down" "Stop Nixfied-owned processes for a slot"
      ''exec "${runtimeBin}" down --model "${modelJson}" "$@"'';
  clean =
    mkApp "clean" "Safely clean Nixfied-owned state for a slot"
      ''exec "${runtimeBin}" clean --model "${modelJson}" "$@"'';
}
// verbApps
